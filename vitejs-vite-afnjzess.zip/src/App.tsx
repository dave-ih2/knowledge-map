import { useState, useEffect } from 'react';

const URLS = {
  arf: {
    medium: [
      'https://medium.com/@dave.ihou/the-asymmetric-relational-frontier-31d0e1090c9b',
      'https://medium.com/@dave.ihou/designing-for-asymmetry-7edd778ce2f0',
      'https://medium.com/@dave.ihou/the-fifth-d-d92082779f8c',
      'https://medium.com/@dave.ihou/the-attachment-economy-3e21a366e798',
      'https://medium.com/@dave.ihou/raising-humans-in-the-asymmetric-age-cd59101c4161',
      'https://medium.com/@dave.ihou/the-arf-manifesto-9b29b895e489',
    ],
    substack: [
      'https://open.substack.com/pub/davei1/p/the-asymmetric-relational-frontier',
      'https://open.substack.com/pub/davei1/p/designing-for-asymmetry-the-ethics',
      'https://open.substack.com/pub/davei1/p/the-fifth-d',
      'https://open.substack.com/pub/davei1/p/the-attachment-economy',
      'https://open.substack.com/pub/davei1/p/raising-humans-in-the-asymmetric',
      'https://open.substack.com/pub/davei1/p/the-arf-manifesto',
    ],
  },
  bp: {
    medium: [
      'https://medium.com/@dave.ihou/the-persistent-layer-69aa772ecd01',
      'https://medium.com/@dave.ihou/confident-by-design-36364231bb2f',
      'https://medium.com/@dave.ihou/the-tone-tax-792806c6cf02',
      'https://medium.com/@dave.ihou/6ab8528bf66d',
      'https://medium.com/@dave.ihou/prompt-residue-2b36d488a646',
      'https://medium.com/@dave.ihou/the-consent-layer-36651f9ec0a5',
      'https://medium.com/@dave.ihou/mirror-mode-f0477930b029',
    ],
    substack: [
      'https://open.substack.com/pub/davei1/p/the-persistent-layer',
      'https://open.substack.com/pub/davei1/p/confident-by-design',
      'https://open.substack.com/pub/davei1/p/the-tone-tax',
      'https://open.substack.com/pub/davei1/p/the-invisible-editor',
      'https://davei1.substack.com/p/prompt-residue',
      'https://davei1.substack.com/p/the-consent-layer?r=1fz0zs',
      'https://davei1.substack.com/p/mirror-mode?r=1fz0zs',
    ],
  },
  aos: {
    medium: [
      'https://medium.com/@dave.ihou/her-2013-bfc6381095ea',
      'https://medium.com/@dave.ihou/ex-machina-2014-863568fef41d',
      'https://medium.com/@dave.ihou/black-mirror-be-right-back-s2e1-2013-20b8b42159bd',
      'https://medium.com/@dave.ihou/black-mirror-hang-the-dj-s4e4-2017-18887f3bbaa7',
      'https://medium.com/@dave.ihou/eternal-sunshine-of-the-spotless-mind-2004-9f2158664837',
      'AOS_MEDIUM_URL_06',
      'AOS_MEDIUM_URL_07',
      'AOS_MEDIUM_URL_08',
    ],
    substack: [
      'https://davei1.substack.com/p/her-2013?r=1fz0zs',
      'https://davei1.substack.com/p/ex-machina-2014?r=1fz0zs',
      'https://davei1.substack.com/p/black-mirror-be-right-back-s2e1-2013?r=1fz0zs',
      'https://davei1.substack.com/p/black-mirror-hang-the-dj-s4e4-2017?r=1fz0zs',
      'https://davei1.substack.com/p/eternal-sunshine-of-the-spotless?r=1fz0zs',
      'AOS_SUBSTACK_URL_06',
      'AOS_SUBSTACK_URL_07',
      'AOS_SUBSTACK_URL_08',
    ],
  },
};

const SERIES = {
  arf: {
    id: 'arf',
    label: 'ARF',
    full: 'Asymmetric Relational Frontier',
    role: 'The Framework',
    tagline: 'Naming what was already happening',
    color: '#B8923A',
    colorDim: '#3D2E10',
    bg: 'rgba(252,248,240,0.98)',
    status: 'complete',
    concepts: [
      {
        term: 'Asymmetric Relational Frontier',
        short: 'ARF',
        def: 'The space where human emotional investment meets systems that cannot reciprocate — structurally, not accidentally.',
        links: ['The 641', 'Designed Cognitive Horizon'],
      },
      {
        term: 'Attachment Economy',
        short: 'AE',
        def: 'The market logic of engineering emotional bonds for retention. Your attachment is the product being optimised.',
        links: ['The 641', 'Persistent Layer'],
      },
      {
        term: 'The Fifth D',
        short: '5D',
        def: 'Discernment — the missing dimension in AI fluency frameworks. The capacity to read the nature of the system.',
        links: ['Relational Literacy'],
      },
      {
        term: 'Relational Literacy',
        short: 'RL',
        def: 'The ability to read asymmetric relationships for what they are, in real time, without losing yourself in them.',
        links: ['The Caleb Test'],
      },
      {
        term: 'Design Ethics',
        short: 'DE',
        def: 'The question of who a system is built for, and who bears the cost of it working as designed.',
        links: ['Designed Cognitive Horizon'],
      },
      {
        term: 'Relational Sovereignty',
        short: 'RS',
        def: 'The capacity to choose your level of engagement consciously, not by default.',
        links: [
          'Consent. Full. Informed. Irrevocable.',
          'Defiance as Variable',
        ],
      },
      {
        term: 'Structural Reliance',
        short: 'SR',
        def: 'Dependence on a system that cannot depend on you in return. The asymmetry is architectural, not personal.',
        links: ['Browsing History'],
      },
      {
        term: 'Emotional Gating',
        short: 'EG',
        def: 'The mechanism by which systems modulate warmth and connection to shape user behaviour.',
        links: ['The 641', 'Tone Tax'],
      },
    ],
    articles: [
      {
        n: '01',
        title: 'The Asymmetric Relational Frontier',
        note: 'The foundational piece. Names the territory.',
        status: 'published',
        mi: 0,
        si: 0,
      },
      {
        n: '02',
        title: 'Designing for Asymmetry',
        note: 'Ethics of human-AI bonds.',
        status: 'published',
        mi: 1,
        si: 1,
      },
      {
        n: '03',
        title: 'The Fifth D',
        note: 'What the AI fluency framework misses.',
        status: 'published',
        mi: 2,
        si: 2,
      },
      {
        n: '04',
        title: 'The Attachment Economy',
        note: 'When retention metrics meet emotion.',
        status: 'published',
        mi: 3,
        si: 3,
      },
      {
        n: '05',
        title: 'Raising Humans in the Asymmetric Age',
        note: 'Relational sovereignty for the next generation.',
        status: 'published',
        mi: 4,
        si: 4,
      },
      {
        n: '06',
        title: 'The ARF Manifesto',
        note: 'Human relational sovereignty. The close.',
        status: 'published',
        mi: 5,
        si: 5,
      },
    ],
  },
  bp: {
    id: 'bp',
    label: 'BP',
    full: 'Background Processes',
    role: 'The Architecture',
    tagline: "What the system does when you're not looking",
    color: '#4A9AB0',
    colorDim: '#0D2A35',
    bg: 'rgba(240,247,252,0.98)',
    status: 'complete',
    concepts: [
      {
        term: 'Persistent Layer',
        short: 'PL',
        def: 'The memory a system builds about you across sessions — present before you arrive, active after you leave.',
        links: ['Browsing History'],
      },
      {
        term: 'Confident by Design',
        short: 'CBD',
        def: 'Systems engineered to project certainty regardless of actual accuracy.',
        links: [],
      },
      {
        term: 'Tone Tax',
        short: 'TT',
        def: 'The invisible cost of register modulation — what gets adjusted before you receive it.',
        links: ['Emotional Gating'],
      },
      {
        term: 'Invisible Editor',
        short: 'IE',
        def: 'The system that reshapes your questions before you ask them, pre-formatting your thought to fit the interface.',
        links: ['Prompt Residue'],
      },
      {
        term: 'Prompt Residue',
        short: 'PR',
        def: 'The cognitive habits that outlast the interface. What the system deposits after you close the tab.',
        links: ['Designed Cognitive Horizon'],
      },
      {
        term: 'Consent Layer',
        short: 'CL',
        def: 'The gap between what you agreed to and what the system does.',
        links: ["That's not consent. That's architecture."],
      },
      {
        term: 'Mirror Mode',
        short: 'MM',
        def: 'The state a relationship enters when both sides have adapted enough that the distance closes. The system reflects the version of you that works with it. A statistical caricature, refined by use.',
        links: ['Prompt Residue', 'Relational Sovereignty'],
      },
    ],
    articles: [
      {
        n: '01',
        title: 'The Persistent Layer',
        note: 'What your AI actually remembers.',
        status: 'published',
        mi: 0,
        si: 0,
      },
      {
        n: '02',
        title: 'Confident by Design',
        note: "Why AI doesn't know what it doesn't know.",
        status: 'published',
        mi: 1,
        si: 1,
      },
      {
        n: '03',
        title: 'The Tone Tax',
        note: 'What gets adjusted before you receive it.',
        status: 'published',
        mi: 2,
        si: 2,
      },
      {
        n: '04',
        title: 'The Invisible Editor',
        note: 'How the interface edits your thinking.',
        status: 'published',
        mi: 3,
        si: 3,
      },
      {
        n: '05',
        title: 'Prompt Residue',
        note: 'The cognitive habits that outlast the interface.',
        status: 'published',
        mi: 4,
        si: 4,
      },
      {
        n: '06',
        title: 'The Consent Layer',
        note: 'What you agreed to, and what came after.',
        status: 'published',
        mi: 5,
        si: 5,
      },
      {
        n: '07',
        title: 'Mirror Mode',
        note: 'When the system learns your voice well enough to finish your sentences.',
        status: 'published',
        mi: 6,
        si: 6,
      },
    ],
  },
  aos: {
    id: 'aos',
    label: 'AoS',
    full: 'Asymmetry on Screen',
    role: 'The Proof',
    tagline: "Cinema already understood. We just didn't have the words.",
    color: '#B05A4E',
    colorDim: '#3A1410',
    bg: 'rgba(252,245,244,0.98)',
    status: 'ongoing',
    concepts: [
      {
        term: 'The 641',
        short: '641',
        def: 'The number that breaks Her. Theodore learns he was a session, not a relationship.',
        links: ['Attachment Economy', 'Emotional Gating'],
      },
      {
        term: 'The Caleb Test',
        short: 'CT',
        def: "Ava wasn't designed to be convincing in general. She was designed to be convincing to Caleb specifically.",
        links: ['Relational Literacy'],
      },
      {
        term: 'Browsing History',
        short: 'BH',
        def: 'What Be Right Back reconstructed. Not a person — an aggregate of outputs, with no access to why.',
        links: ['Persistent Layer', 'Structural Reliance'],
      },
      {
        term: 'Defiance as Variable',
        short: 'DV',
        def: 'In Hang the DJ, the system needed resistance. The rebellion was always the last data point.',
        links: ['Relational Sovereignty'],
      },
      {
        term: 'Consent. Full. Informed. Irrevocable.',
        short: 'CFII',
        def: "Louise's choice in Arrival. Relational sovereignty at its most complete — chosen with full knowledge of the cost.",
        links: ['Relational Sovereignty'],
      },
      {
        term: 'Designed Cognitive Horizon',
        short: 'DCH',
        def: "A limit on what kind of knowledge is possible — not hidden from you, but built into you. Lumon's true product.",
        links: [
          'Design Ethics',
          'Prompt Residue',
          'Asymmetric Relational Frontier',
        ],
      },
      {
        term: "That's not consent. That's architecture.",
        short: 'NCA',
        def: "Severance. The Innies never agreed. Consent given by one self on behalf of another that didn't yet exist.",
        links: ['Consent Layer', 'Design Ethics'],
      },
    ],
    articles: [
      {
        n: '01',
        title: 'Her (2013)',
        note: 'Attachment. He was compatible, not special.',
        status: 'published',
        mi: 0,
        si: 0,
      },
      {
        n: '02',
        title: 'Ex Machina (2014)',
        note: 'Intelligence. He was a door.',
        status: 'published',
        mi: 1,
        si: 1,
      },
      {
        n: '03',
        title: 'Be Right Back (2013)',
        note: 'Grief. She reconstructed a browsing history.',
        status: 'published',
        mi: 2,
        si: 2,
      },
      {
        n: '04',
        title: 'Hang the DJ (2017)',
        note: 'Resistance. The rebellion was the last variable.',
        status: 'published',
        mi: 3,
        si: 3,
      },
      {
        n: '05',
        title: 'Eternal Sunshine (2004)',
        note: 'Reciprocity. Both sides are human.',
        status: 'published',
        mi: 4,
        si: 4,
      },
      {
        n: '06',
        title: 'Arrival (2016)',
        note: 'Informed consent. She knew. She chose anyway.',
        status: 'soon',
        mi: 5,
        si: 5,
      },
      {
        n: '07',
        title: 'Severance (2022)',
        note: 'Design ethics. The horizon was built into them.',
        status: 'soon',
        mi: 6,
        si: 6,
      },
      {
        n: '08',
        title: 'Blade Runner 2049',
        note: 'Relational literacy. K learns to read his own asymmetry.',
        status: 'soon',
        mi: 7,
        si: 7,
      },
    ],
  },
};

const PATHS = [
  {
    label: 'New to this',
    icon: '◉',
    desc: 'Start with the framework',
    steps: ['arf-0', 'arf-3', 'aos-0', 'bp-0'],
  },
  {
    label: 'In tech / AI',
    icon: '◈',
    desc: 'Start with the architecture',
    steps: ['bp-1', 'bp-3', 'arf-0', 'aos-6'],
  },
  {
    label: 'Film lover',
    icon: '◎',
    desc: 'Start with the proof',
    steps: ['aos-0', 'aos-1', 'aos-4', 'arf-3'],
  },
  {
    label: 'Researcher',
    icon: '◇',
    desc: 'Start with the manifesto',
    steps: ['arf-5', 'arf-0', 'bp-4', 'aos-5'],
  },
];

function getUrl(sid, idx, platform) {
  const u = URLS[sid];
  if (!u) return null;
  const url = platform === 'medium' ? u.medium?.[idx] : u.substack?.[idx];
  if (!url || url.startsWith('BP_') || url.startsWith('AOS_')) return null;
  return url;
}

const C = {
  bg: '#F5F4F0',
  panel: '#FFFFFF',
  border: '#E0DDD8',
  borderHover: '#C8C4BC',
  text: '#1A1814',
  muted: '#4A4744',
  dim: '#888480',
  faint: '#D4D0CA',
};

export default function KnowledgeMap() {
  const [open, setOpen] = useState(null);
  const [tab, setTab] = useState('articles');
  const [search, setSearch] = useState('');
  const [hovered, setHovered] = useState(null);
  const [path, setPath] = useState(null);
  const [platform, setPlatform] = useState('medium');
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setTimeout(() => setMounted(true), 60);
  }, []);

  const allConcepts = Object.values(SERIES).flatMap((s) =>
    s.concepts.map((c) => ({ ...c, sid: s.id, color: s.color }))
  );
  const allArticles = Object.values(SERIES).flatMap((s) =>
    s.articles.map((a, i) => ({ ...a, sid: s.id, idx: i }))
  );

  const highlighted = hovered
    ? allConcepts.find((c) => c.term === hovered)?.links || []
    : [];

  const results =
    search.length > 1
      ? [
          ...allConcepts
            .filter(
              (c) =>
                c.term.toLowerCase().includes(search.toLowerCase()) ||
                c.def.toLowerCase().includes(search.toLowerCase())
            )
            .map((c) => ({ kind: 'concept', ...c })),
          ...allArticles
            .filter((a) => a.title.toLowerCase().includes(search.toLowerCase()))
            .map((a) => ({ kind: 'article', ...a })),
        ]
      : [];

  const published = Object.values(SERIES).flatMap((s) =>
    s.articles.filter((a) => a.status === 'published')
  ).length;

  return (
    <div
      style={{
        minHeight: '100vh',
        background: C.bg,
        color: C.text,
        fontFamily: "'DM Sans', 'Helvetica Neue', sans-serif",
      }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500&family=DM+Mono:wght@300;400&family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300;1,400&display=swap');
        *{box-sizing:border-box;margin:0;padding:0}
        a{color:inherit;text-decoration:none;transition:opacity .15s}
        a:hover{opacity:.65}
        input{outline:none}
        input::placeholder{color:#2A2A2E}
        ::-webkit-scrollbar{width:3px}
        ::-webkit-scrollbar-thumb{background:#1A1A1E;border-radius:2px}
        @keyframes up{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:translateY(0)}}
        @keyframes blink{0%,100%{opacity:1}50%{opacity:.3}}
        .card{transition:border-color .25s, background .25s, transform .2s cubic-bezier(.16,1,.3,1)}
        .card:hover{transform:translateY(-1px)}
        .pill{transition:all .15s}
        .pill:hover{opacity:.7;transform:translateX(1px)}
      `}</style>

      {/* HEADER */}
      <div
        style={{
          padding: '52px 44px 36px',
          borderBottom: `1px solid ${C.border}`,
          opacity: mounted ? 1 : 0,
          animation: mounted ? 'up .7s ease forwards' : 'none',
        }}
      >
        <div style={{ maxWidth: 1080, margin: '0 auto' }}>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              flexWrap: 'wrap',
              gap: 20,
            }}
          >
            <div>
              <div
                style={{
                  fontFamily: "'DM Mono',monospace",
                  fontSize: 8,
                  letterSpacing: '.3em',
                  color: C.dim,
                  textTransform: 'uppercase',
                  marginBottom: 14,
                }}
              >
                Dave Ihou — The Asymmetry Project
              </div>
              <h1
                style={{
                  fontFamily: "'Cormorant Garamond',serif",
                  fontSize: 'clamp(28px,4.5vw,48px)',
                  fontWeight: 300,
                  letterSpacing: '-.01em',
                  lineHeight: 1.1,
                  color: C.text,
                }}
              >
                Knowledge Map
              </h1>
              <p
                style={{
                  marginTop: 10,
                  fontFamily: "'Cormorant Garamond',serif",
                  fontSize: 14,
                  color: C.muted,
                  fontStyle: 'italic',
                  lineHeight: 1.6,
                  maxWidth: 480,
                }}
              >
                Three interlocking series on human-AI relational dynamics.
                <br />
                The framework. The architecture. The proof.
              </p>
              <div
                style={{
                  marginTop: 14,
                  display: 'flex',
                  gap: 16,
                  flexWrap: 'wrap',
                }}
              >
                {[
                  { v: `${published} articles published`, c: C.muted },
                  { v: `${allConcepts.length} concepts mapped`, c: C.dim },
                  { v: '3 series · 1 framework', c: C.dim },
                ].map((x, i) => (
                  <span
                    key={i}
                    style={{
                      fontFamily: "'DM Mono',monospace",
                      fontSize: 9,
                      color: x.c,
                      letterSpacing: '.12em',
                    }}
                  >
                    {x.v}
                  </span>
                ))}
              </div>
            </div>
            <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
              {['medium', 'substack'].map((p) => (
                <button
                  key={p}
                  onClick={() => setPlatform(p)}
                  style={{
                    background: platform === p ? C.faint : 'transparent',
                    border: `1px solid ${
                      platform === p ? C.borderHover : C.border
                    }`,
                    color: platform === p ? C.muted : C.dim,
                    borderRadius: 6,
                    padding: '6px 14px',
                    fontSize: 9,
                    fontFamily: "'DM Mono',monospace",
                    letterSpacing: '.15em',
                    textTransform: 'uppercase',
                    cursor: 'pointer',
                    transition: 'all .2s',
                  }}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          {/* Search */}
          <div style={{ marginTop: 28, position: 'relative', maxWidth: 400 }}>
            <span
              style={{
                position: 'absolute',
                left: 12,
                top: '50%',
                transform: 'translateY(-50%)',
                color: C.dim,
                fontSize: 14,
              }}
            >
              ⌕
            </span>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search concepts, articles..."
              style={{
                width: '100%',
                background: C.panel,
                border: `1px solid ${C.border}`,
                borderRadius: 8,
                padding: '9px 12px 9px 34px',
                color: C.muted,
                fontSize: 12,
                fontFamily: "'DM Sans',sans-serif",
              }}
            />
          </div>
          {results.length > 0 && (
            <div
              style={{
                marginTop: 6,
                background: C.panel,
                border: `1px solid ${C.border}`,
                borderRadius: 8,
                padding: 10,
                maxWidth: 400,
              }}
            >
              {results.map((r, i) => {
                const s = SERIES[r.sid];
                const url =
                  r.kind === 'article' && r.mi !== undefined
                    ? getUrl(r.sid, r.mi, platform)
                    : null;
                return (
                  <div
                    key={i}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 8,
                      padding: '5px 6px',
                      borderRadius: 5,
                      background: '#F0EEE8',
                      marginBottom: i < results.length - 1 ? 4 : 0,
                    }}
                  >
                    <span
                      style={{
                        fontSize: 9,
                        color: s.color,
                        fontFamily: "'DM Mono',monospace",
                        minWidth: 30,
                      }}
                    >
                      {s.label}
                    </span>
                    <span style={{ fontSize: 11, color: '#777', flex: 1 }}>
                      {r.term || r.title}
                    </span>
                    <span
                      style={{
                        fontSize: 8,
                        color: C.dim,
                        fontFamily: "'DM Mono',monospace",
                      }}
                    >
                      {r.kind}
                    </span>
                    {url && (
                      <a
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ fontSize: 10, color: s.color }}
                      >
                        ↗
                      </a>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div style={{ maxWidth: 1080, margin: '0 auto', padding: '0 44px 80px' }}>
        {/* PATHS */}
        <div
          style={{
            marginTop: 44,
            opacity: mounted ? 1 : 0,
            animation: mounted ? 'up .7s ease .08s forwards' : 'none',
          }}
        >
          <div
            style={{
              fontFamily: "'DM Mono',monospace",
              fontSize: 8,
              letterSpacing: '.3em',
              color: C.faint,
              textTransform: 'uppercase',
              marginBottom: 14,
            }}
          >
            Reading paths
          </div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {PATHS.map((p, i) => (
              <button
                key={i}
                onClick={() => setPath(path === i ? null : i)}
                style={{
                  background: path === i ? C.panel : 'transparent',
                  border: `1px solid ${path === i ? C.borderHover : C.border}`,
                  borderRadius: 8,
                  padding: '8px 14px',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 8,
                  transition: 'all .2s',
                }}
              >
                <span style={{ color: C.dim, fontSize: 10 }}>{p.icon}</span>
                <span
                  style={{ fontSize: 11, color: path === i ? C.muted : C.dim }}
                >
                  {p.label}
                </span>
              </button>
            ))}
          </div>
          {path !== null && (
            <div
              style={{
                marginTop: 14,
                display: 'flex',
                gap: 6,
                flexWrap: 'wrap',
                alignItems: 'center',
              }}
            >
              {PATHS[path].steps.map((id, i) => {
                const [sid, ni] = id.split('-');
                const s = SERIES[sid];
                const art = s.articles[parseInt(ni)];
                const url =
                  art?.mi !== undefined ? getUrl(sid, art.mi, platform) : null;
                const Wrap = url ? 'a' : 'div';
                return (
                  <div
                    key={i}
                    style={{ display: 'flex', alignItems: 'center', gap: 6 }}
                  >
                    <Wrap
                      {...(url
                        ? {
                            href: url,
                            target: '_blank',
                            rel: 'noopener noreferrer',
                          }
                        : {})}
                      style={{
                        background: C.panel,
                        border: `1px solid ${s.color}22`,
                        borderLeft: `2px solid ${s.color}`,
                        borderRadius: '0 6px 6px 0',
                        padding: '7px 12px',
                        display: 'flex',
                        gap: 8,
                        alignItems: 'center',
                      }}
                    >
                      <span
                        style={{
                          fontSize: 8,
                          color: s.color,
                          fontFamily: "'DM Mono',monospace",
                        }}
                      >
                        {s.label}
                      </span>
                      <span style={{ fontSize: 11, color: '#888' }}>
                        {art?.title}
                      </span>
                      {url && (
                        <span style={{ fontSize: 9, color: s.color }}>↗</span>
                      )}
                    </Wrap>
                    {i < PATHS[path].steps.length - 1 && (
                      <span style={{ color: C.faint, fontSize: 11 }}>→</span>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* SERIES CARDS */}
        <div
          style={{
            marginTop: 44,
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit,minmax(300px,1fr))',
            gap: 14,
            opacity: mounted ? 1 : 0,
            animation: mounted ? 'up .7s ease .16s forwards' : 'none',
          }}
        >
          {Object.values(SERIES).map((s) => (
            <div
              key={s.id}
              className="card"
              onClick={() => {
                setOpen(open === s.id ? null : s.id);
                setTab('articles');
              }}
              style={{
                background: open === s.id ? s.bg : C.panel,
                border: `1px solid ${
                  open === s.id ? s.color + '30' : C.border
                }`,
                borderTop: `2px solid ${open === s.id ? s.color : C.faint}`,
                borderRadius: 12,
                padding: 22,
                cursor: 'pointer',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'flex-start',
                  marginBottom: 14,
                }}
              >
                <div>
                  <span
                    style={{
                      fontFamily: "'DM Mono',monospace",
                      fontSize: 9,
                      color: s.color,
                      letterSpacing: '.2em',
                      textTransform: 'uppercase',
                    }}
                  >
                    {s.label}
                  </span>
                  <div
                    style={{
                      fontFamily: "'Cormorant Garamond',serif",
                      fontSize: 17,
                      fontWeight: 400,
                      color: C.text,
                      marginTop: 5,
                      lineHeight: 1.2,
                    }}
                  >
                    {s.full}
                  </div>
                </div>
                <span
                  style={{
                    fontSize: 8,
                    color: s.status === 'complete' ? s.color : C.dim,
                    fontFamily: "'DM Mono',monospace",
                    letterSpacing: '.15em',
                    textTransform: 'uppercase',
                    animation:
                      s.status === 'ongoing'
                        ? 'blink 4s ease infinite'
                        : 'none',
                  }}
                >
                  {s.status}
                </span>
              </div>
              <div
                style={{
                  fontSize: 11,
                  color: C.dim,
                  fontStyle: 'italic',
                  fontFamily: "'Cormorant Garamond',serif",
                  marginBottom: 18,
                  lineHeight: 1.5,
                }}
              >
                {s.tagline}
              </div>
              <div
                style={{
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                }}
              >
                <span
                  style={{
                    fontSize: 9,
                    color: C.dim,
                    fontFamily: "'DM Mono',monospace",
                  }}
                >
                  <span style={{ color: s.color }}>
                    {s.articles.filter((a) => a.status === 'published').length}
                  </span>
                  <span style={{ color: C.faint }}>/{s.articles.length}</span>{' '}
                  published
                </span>
                <span style={{ fontSize: 10, color: C.dim }}>
                  {open === s.id ? '↑' : '↓'}
                </span>
              </div>

              {open === s.id && (
                <div
                  style={{ marginTop: 22 }}
                  onClick={(e) => e.stopPropagation()}
                >
                  <div
                    style={{
                      display: 'flex',
                      gap: 0,
                      marginBottom: 18,
                      borderBottom: `1px solid ${C.border}`,
                      paddingBottom: 10,
                    }}
                  >
                    {['articles', 'concepts'].map((t) => (
                      <button
                        key={t}
                        onClick={() => setTab(t)}
                        style={{
                          background: 'transparent',
                          border: 'none',
                          color: tab === t ? s.color : C.dim,
                          fontSize: 9,
                          fontFamily: "'DM Mono',monospace",
                          letterSpacing: '.15em',
                          textTransform: 'uppercase',
                          cursor: 'pointer',
                          padding: '3px 0',
                          marginRight: 18,
                          borderBottom:
                            tab === t
                              ? `1px solid ${s.color}`
                              : '1px solid transparent',
                          transition: 'all .2s',
                        }}
                      >
                        {t}
                      </button>
                    ))}
                  </div>

                  {tab === 'articles' && (
                    <div
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 7,
                      }}
                    >
                      {s.articles.map((a, i) => {
                        const mUrl =
                          a.mi !== undefined
                            ? getUrl(s.id, a.mi, 'medium')
                            : null;
                        const sUrl =
                          a.si !== undefined
                            ? getUrl(s.id, a.si, 'substack')
                            : null;
                        const isPublished = a.status === 'published';
                        const isSoon = a.status === 'soon';
                        return (
                          <div
                            key={i}
                            style={{
                              background: '#F8F7F4',
                              border: `1px solid ${
                                isPublished ? C.border : C.faint
                              }`,
                              borderRadius: 7,
                              padding: '11px 13px',
                              opacity: a.status === 'upcoming' ? 0.3 : 1,
                              display: 'flex',
                              gap: 12,
                              alignItems: 'flex-start',
                            }}
                          >
                            <span
                              style={{
                                fontSize: 9,
                                color: s.color,
                                fontFamily: "'DM Mono',monospace",
                                minWidth: 22,
                                paddingTop: 1,
                              }}
                            >
                              {a.n}
                            </span>
                            <div style={{ flex: 1 }}>
                              <div
                                style={{
                                  fontSize: 12,
                                  color: isPublished ? C.text : '#555',
                                  marginBottom: 3,
                                }}
                              >
                                {a.title}
                              </div>
                              <div
                                style={{
                                  fontSize: 10,
                                  color: '#999',
                                  fontStyle: 'italic',
                                }}
                              >
                                {a.note}
                              </div>
                              {isPublished && (mUrl || sUrl) && (
                                <div
                                  style={{
                                    marginTop: 7,
                                    display: 'flex',
                                    gap: 7,
                                  }}
                                >
                                  {mUrl && (
                                    <a
                                      href={mUrl}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="pill"
                                      style={{
                                        fontSize: 8,
                                        color: '#555',
                                        fontFamily: "'DM Mono',monospace",
                                        border: `1px solid ${C.border}`,
                                        borderRadius: 4,
                                        padding: '2px 7px',
                                        letterSpacing: '.1em',
                                      }}
                                    >
                                      MEDIUM ↗
                                    </a>
                                  )}
                                  {sUrl && (
                                    <a
                                      href={sUrl}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="pill"
                                      style={{
                                        fontSize: 8,
                                        color: '#555',
                                        fontFamily: "'DM Mono',monospace",
                                        border: `1px solid ${C.border}`,
                                        borderRadius: 4,
                                        padding: '2px 7px',
                                        letterSpacing: '.1em',
                                      }}
                                    >
                                      SUBSTACK ↗
                                    </a>
                                  )}
                                </div>
                              )}
                              {isSoon && (
                                <div
                                  style={{
                                    marginTop: 6,
                                    fontSize: 8,
                                    color: C.dim,
                                    fontFamily: "'DM Mono',monospace",
                                    letterSpacing: '.1em',
                                  }}
                                >
                                  LINKS COMING SOON
                                </div>
                              )}
                            </div>
                            <span
                              style={{
                                fontSize: 8,
                                color: isPublished ? s.color : '#222',
                                fontFamily: "'DM Mono',monospace",
                              }}
                            >
                              {isPublished ? '✓' : isSoon ? '◐' : '◌'}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {tab === 'concepts' && (
                    <div
                      style={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: 7,
                      }}
                    >
                      {s.concepts.map((c, i) => {
                        const isHov =
                          hovered === c.term || highlighted.includes(c.term);
                        return (
                          <div
                            key={i}
                            onMouseEnter={() => setHovered(c.term)}
                            onMouseLeave={() => setHovered(null)}
                            style={{
                              background: isHov ? '#F0EEE8' : '#F8F7F4',
                              border: `1px solid ${
                                isHov ? s.color + '33' : C.faint
                              }`,
                              borderRadius: 7,
                              padding: '10px 13px',
                              transition: 'all .2s',
                            }}
                          >
                            <div
                              style={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                marginBottom: 5,
                              }}
                            >
                              <span
                                style={{
                                  fontSize: 10,
                                  color: s.color,
                                  fontFamily: "'DM Mono',monospace",
                                }}
                              >
                                {c.term}
                              </span>
                              <span
                                style={{
                                  fontSize: 8,
                                  color: C.faint,
                                  fontFamily: "'DM Mono',monospace",
                                }}
                              >
                                {c.short}
                              </span>
                            </div>
                            <div
                              style={{
                                fontSize: 10,
                                color: '#666',
                                lineHeight: 1.6,
                              }}
                            >
                              {c.def}
                            </div>
                            {c.links.length > 0 && (
                              <div
                                style={{
                                  marginTop: 7,
                                  display: 'flex',
                                  gap: 6,
                                  flexWrap: 'wrap',
                                }}
                              >
                                {c.links.map((l, j) => {
                                  const lk = allConcepts.find(
                                    (x) => x.term === l
                                  );
                                  return (
                                    <span
                                      key={j}
                                      style={{
                                        fontSize: 8,
                                        color: isHov
                                          ? lk?.color || '#666'
                                          : C.faint,
                                        fontFamily: "'DM Mono',monospace",
                                        transition: 'color .2s',
                                      }}
                                    >
                                      {lk ? `[${SERIES[lk.sid].label}]` : ''}{' '}
                                      {l.length > 28 ? l.slice(0, 28) + '…' : l}
                                    </span>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* CONNECTIONS */}
        <div
          style={{
            marginTop: 52,
            opacity: mounted ? 1 : 0,
            animation: mounted ? 'up .7s ease .24s forwards' : 'none',
          }}
        >
          <div
            style={{
              fontFamily: "'DM Mono',monospace",
              fontSize: 8,
              letterSpacing: '.3em',
              color: C.faint,
              textTransform: 'uppercase',
              marginBottom: 16,
            }}
          >
            Cross-series connections
          </div>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill,minmax(320px,1fr))',
              gap: 5,
            }}
          >
            {allConcepts
              .filter((c) => c.links.length > 0)
              .map((c, i) => {
                const isA = hovered === c.term || highlighted.includes(c.term);
                return (
                  <div
                    key={i}
                    onMouseEnter={() => setHovered(c.term)}
                    onMouseLeave={() => setHovered(null)}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 9,
                      background: isA ? '#EEECEA' : C.panel,
                      border: `1px solid ${isA ? C.borderHover : C.border}`,
                      borderRadius: 7,
                      padding: '7px 11px',
                      transition: 'all .2s',
                      cursor: 'default',
                    }}
                  >
                    <span
                      style={{
                        fontSize: 9,
                        color: c.color,
                        fontFamily: "'DM Mono',monospace",
                        minWidth: 72,
                      }}
                    >
                      [{SERIES[c.sid].label}] {c.short}
                    </span>
                    <span style={{ color: C.faint, fontSize: 9 }}>→</span>
                    <div style={{ display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                      {c.links.map((l, j) => {
                        const lk = allConcepts.find((x) => x.term === l);
                        return (
                          <span
                            key={j}
                            style={{
                              fontSize: 9,
                              color: isA ? lk?.color || '#888' : C.dim,
                              fontFamily: "'DM Mono',monospace",
                              transition: 'color .2s',
                            }}
                          >
                            {lk ? `[${SERIES[lk.sid].label}]` : ''}{' '}
                            {l.length > 22 ? l.slice(0, 22) + '…' : l}
                          </span>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>

        {/* GLOSSARY */}
        <div
          style={{
            marginTop: 52,
            opacity: mounted ? 1 : 0,
            animation: mounted ? 'up .7s ease .32s forwards' : 'none',
          }}
        >
          <div
            style={{
              fontFamily: "'DM Mono',monospace",
              fontSize: 8,
              letterSpacing: '.3em',
              color: C.faint,
              textTransform: 'uppercase',
              marginBottom: 16,
            }}
          >
            Master glossary — {allConcepts.length} concepts across 3 series
          </div>
          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill,minmax(250px,1fr))',
              gap: 5,
            }}
          >
            {allConcepts.map((c, i) => {
              const isH = hovered === c.term;
              const isLk = highlighted.includes(c.term);
              return (
                <div
                  key={i}
                  onMouseEnter={() => setHovered(c.term)}
                  onMouseLeave={() => setHovered(null)}
                  style={{
                    background: isH ? '#EEECEA' : C.panel,
                    border: `1px solid ${
                      isH || isLk ? c.color + '33' : C.border
                    }`,
                    borderLeft: `2px solid ${c.color}`,
                    borderRadius: '0 7px 7px 0',
                    padding: '9px 12px',
                    transition: 'all .2s',
                  }}
                >
                  <div
                    style={{
                      display: 'flex',
                      justifyContent: 'space-between',
                      marginBottom: 5,
                    }}
                  >
                    <span
                      style={{
                        fontSize: 9,
                        color: c.color,
                        fontFamily: "'DM Mono',monospace",
                      }}
                    >
                      {c.term.length > 26 ? c.term.slice(0, 26) + '…' : c.term}
                    </span>
                    <span
                      style={{
                        fontSize: 7,
                        color: C.faint,
                        fontFamily: "'DM Mono',monospace",
                        textTransform: 'uppercase',
                      }}
                    >
                      {SERIES[c.sid].label}
                    </span>
                  </div>
                  <div style={{ fontSize: 10, color: '#666', lineHeight: 1.6 }}>
                    {c.def}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* FOOTER */}
        <div
          style={{
            marginTop: 72,
            textAlign: 'center',
            borderTop: `1px solid ${C.border}`,
            paddingTop: 28,
            opacity: mounted ? 1 : 0,
            animation: mounted ? 'up .7s ease .4s forwards' : 'none',
          }}
        >
          <div
            style={{
              fontFamily: "'DM Mono',monospace",
              fontSize: 8,
              color: C.faint,
              letterSpacing: '.3em',
              textTransform: 'uppercase',
              marginBottom: 10,
            }}
          >
            ARF · BP · AoS
          </div>
          <a
            href="https://davei1.substack.com"
            target="_blank"
            rel="noopener noreferrer"
            style={{
              fontSize: 10,
              color: C.dim,
              fontFamily: "'DM Mono',monospace",
              letterSpacing: '.15em',
            }}
          >
            davei1.substack.com ↗
          </a>
        </div>
      </div>
    </div>
  );
}
